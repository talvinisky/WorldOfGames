from Live import load_game, welcome


name = input("enter your name: ")
print(welcome(name))

load_game()

